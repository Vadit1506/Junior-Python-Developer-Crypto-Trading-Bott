# 🚀 Bybit Futures Trading Bot

Advanced trading bot with 6 order types, simulation mode, and CI/CD pipeline.

## Features
- 6 Order Types: Market, Limit, Stop-Limit, OCO, TWAP, Grid
- Simulation Mode (default ON)
- Dual Authentication (API Key + OAuth)
- Auto-generated UI via CodeWords

## Quick Start
\`\`\`bash
pip install -r requirements.txt
python trading_bot.py
\`\`\`

Visit http://localhost:8000/docs for API documentation.

## Live Demo
Try it on CodeWords: https://codewords.agemo.ai/run/binance_futures_trading_bot_550b7481
